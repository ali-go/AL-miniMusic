# AL-miniMusic
a project about mini music

这是一个关于音乐播放器的微信小程序

考虑到依赖版本原因，完整代码包括依赖的压缩包都进行了上传
